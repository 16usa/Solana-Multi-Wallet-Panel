#!/usr/bin/env bash
set -euo pipefail

TARGETS=(
  "artifacts/api-server/src/routes/execution.ts"
  "artifacts/api-server/src/lib/execution-engine.ts"
  "artifacts/api-server/src/lib/strategy-worker.ts"
)

for file in "${TARGETS[@]}"; do
  if [ ! -f "$file" ]; then
    echo "ERROR: expected file not found: $file"
    exit 1
  fi
  cp "$file" "$file.bak-v7.0"
done

python3 patch/apply-v7-0.py

echo
echo "v7.0 AUTO/manual coordination installed."
echo "Fixes weighted entry price across additional buys."
echo "Fixes manual full SELL so AUTO closes cleanly."
echo "Manual trades now temporarily lock AUTO execution."
echo "No server restart was performed."
echo "No Console commands were run."
echo "Run: bash push-v7.0.sh"
