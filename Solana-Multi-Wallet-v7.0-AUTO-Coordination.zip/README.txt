Solana Multi Wallet v7.0 — AUTO/manual coordination

This patch fixes the two interaction problems discussed:

1) Multiple BUYs now use a weighted entry price.
   Example:
   - existing position is kept at its stored entry price
   - newly acquired tokens are added using the actual SOL amount spent
   - TP/SL then tracks the combined weighted entry instead of only the latest BUY price

2) Manual SELL and AUTO no longer fight each other.
   - Manual trade temporarily marks an enabled strategy as executing
   - AUTO worker re-checks the strategy immediately before executing
   - Manual partial SELL returns AUTO to watching for the remaining position
   - Manual 100% SELL disables AUTO, marks the position closed, and clears entry price
   - SELL ALL at 100% does the same independently for each successful wallet
   - If AUTO is already executing, the manual trade is rejected for that wallet instead of racing it

Notes:
- No database schema migration is required.
- No frontend/UI changes are made.
- If entry tracking fails after a confirmed BUY, the trade itself is still reported as successful and the tracking error is logged instead of falsely reporting that the blockchain BUY failed.
- Existing old entry prices remain as-is until the next BUY/position cycle.

Install:
  unzip -o Solana-Multi-Wallet-v7.0-AUTO-Coordination.zip
  bash install.sh
  bash push-v7.0.sh

No server restart is performed by this patch.
After push, restart the API Server manually from Replit Console when you are ready.
