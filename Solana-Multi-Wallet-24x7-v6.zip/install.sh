#!/usr/bin/env bash
set -euo pipefail

TARGETS=(
  "lib/db/src/schema/index.ts"
  "artifacts/api-server/src/routes/index.ts"
  "artifacts/api-server/src/index.ts"
  "artifacts/api-server/src/app.ts"
  "artifacts/solana-multi-wallet/src/App.tsx"
  "artifacts/solana-multi-wallet/src/pages/home.tsx"
  "artifacts/solana-multi-wallet/src/index.css"
  ".replit"
)

for file in "${TARGETS[@]}"; do
  if [ ! -f "$file" ]; then
    echo "ERROR: expected project file not found: $file"
    exit 1
  fi
  cp "$file" "$file.bak-v6"
done

mkdir -p lib/db/src/schema
mkdir -p artifacts/api-server/src/lib
mkdir -p artifacts/api-server/src/routes
mkdir -p scripts

cp patch/lib/db/src/schema/execution.ts lib/db/src/schema/execution.ts
cp patch/lib/db/src/schema/index.ts lib/db/src/schema/index.ts
cp patch/artifacts/api-server/src/lib/execution-vault.ts artifacts/api-server/src/lib/execution-vault.ts
cp patch/artifacts/api-server/src/lib/execution-engine.ts artifacts/api-server/src/lib/execution-engine.ts
cp patch/artifacts/api-server/src/lib/strategy-worker.ts artifacts/api-server/src/lib/strategy-worker.ts
cp patch/artifacts/api-server/src/routes/execution.ts artifacts/api-server/src/routes/execution.ts
cp patch/artifacts/api-server/src/routes/index.ts artifacts/api-server/src/routes/index.ts
cp patch/artifacts/api-server/src/index.ts artifacts/api-server/src/index.ts
cp patch/artifacts/api-server/src/app.ts artifacts/api-server/src/app.ts
cp patch/artifacts/solana-multi-wallet/src/App.tsx artifacts/solana-multi-wallet/src/App.tsx
cp patch/artifacts/solana-multi-wallet/src/pages/home.tsx artifacts/solana-multi-wallet/src/pages/home.tsx
cp patch/artifacts/solana-multi-wallet/src/index.css artifacts/solana-multi-wallet/src/index.css
cp patch/scripts/build-24x7.sh scripts/build-24x7.sh
cp patch/scripts/run-24x7.sh scripts/run-24x7.sh
cp patch/.replit .replit

chmod +x scripts/build-24x7.sh scripts/run-24x7.sh

echo
echo "24/7 Execution v6 installed."
echo "NO server restart was performed."
echo "NO Console restart command was run."
echo
echo "Before restarting, configure DATABASE_URL, EXECUTION_MASTER_KEY,"
echo "PANEL_API_TOKEN and SOLANA_RPC_URL in Replit Secrets."
echo "Then run: bash setup-24x7.sh"
echo "Then run: bash push.sh"
