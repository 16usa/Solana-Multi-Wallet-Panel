Solana Multi Wallet — 24/7 Execution v6

This patch REPLACES Phantom execution with dedicated managed execution wallets.

Security model:
- The backend generates dedicated Solana trading wallets.
- Private keys never appear in the browser.
- Wallet secret keys are AES-256-GCM encrypted before database storage.
- The AES master key exists only in Replit Secrets as EXECUTION_MASTER_KEY.
- Protected execution endpoints require PANEL_API_TOKEN.
- Use only dedicated hot wallets with limited trading funds.
- Do not use a main savings wallet.

24/7 behavior:
- Manual BUY/SELL is signed and submitted by the backend.
- BUY ALL / SELL ALL works without Phantom.
- TP %, TP SELL %, SL %, and SL SELL % are stored persistently.
- A backend worker checks enabled strategies every 5 seconds.
- TP/SL can execute while the phone/browser is closed.
- Automatic TP/SL currently supports Pump.fun price monitoring.
- Non-Pump manual routes require JUPITER_API_KEY.

Replit requirement:
Autoscale can scale to zero. True 24/7 requires a Reserved VM deployment.
This patch changes .replit deploymentTarget to reserved-vm and supplies:
  Build: bash scripts/build-24x7.sh
  Run:   bash scripts/run-24x7.sh

Required Replit Secrets:
- DATABASE_URL
- EXECUTION_MASTER_KEY   (exactly 32 random bytes, base64 encoded)
- PANEL_API_TOKEN        (long random secret)
- SOLANA_RPC_URL
Optional:
- JUPITER_API_KEY

Generate safe values in Shell:
python3 - <<'PY'
import base64, secrets
print("EXECUTION_MASTER_KEY=" + base64.b64encode(secrets.token_bytes(32)).decode())
print("PANEL_API_TOKEN=" + secrets.token_urlsafe(32))
PY

Copy those two values into Replit Secrets. Do NOT commit them.

Install:
unzip -o Solana-Multi-Wallet-24x7-v6.zip
bash install.sh

After adding/provisioning DATABASE_URL and the Secrets:
bash setup-24x7.sh
bash push.sh

No restart is performed by any patch script.
Restart/publish manually only after setup succeeds.
