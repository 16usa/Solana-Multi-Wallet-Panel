Solana Multi Wallet v6.7 — software palette experiment

This patch changes ONLY colors / visual states.

Dark theme:
- Graphite-black background instead of flat pure black
- Dark raised inputs and controls
- Blue system/status accent
- BUY/SELL remain neutral at rest
- BUY flashes green on interaction
- SELL flashes red on interaction
- TP uses restrained green text
- SL uses restrained red text
- AUTO ON uses blue
- 24/7 uses blue status styling
- Delete uses red only where semantically destructive

Light theme:
- Soft #F6F7F9 app background
- White inputs/surfaces
- Softer grey dividers
- Same semantic blue/green/red system

Install:
  unzip -o Solana-Multi-Wallet-v6.7-Software-Palette.zip
  bash install.sh
  bash push-v6.7.sh

If you do not like the new palette:
  bash rollback-v6.7.sh

The rollback removes only the v6.7 CSS block, commits it, and pushes it.
It does not restart the server.
