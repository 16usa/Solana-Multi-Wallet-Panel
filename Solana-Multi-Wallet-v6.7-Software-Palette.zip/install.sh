#!/usr/bin/env bash
set -euo pipefail

python3 patch/apply-v6-7.py

echo
echo "v6.7 software palette installed."
echo "Visual/CSS only. No trading or backend logic changed."
echo "No server restart was performed."
echo "No Console commands were run."
echo "Run: bash push-v6.7.sh"
echo "If you do not like it later: bash rollback-v6.7.sh"
