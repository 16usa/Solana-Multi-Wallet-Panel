Solana Multi Wallet v6.9 — per-wallet trade amounts

Changes:
- Every execution wallet gets its own BUY amount in SOL.
- Every execution wallet gets its own SELL percentage.
- Individual BUY uses that wallet's BUY SOL amount.
- Individual SELL uses that wallet's SELL percentage.
- Trade all remains separate:
    Buy / wallet -> used only by BUY ALL
    Sell / wallet -> used only by SELL ALL
- Per-wallet values are saved locally in the browser/device.
- New wallets default to the current global Buy / wallet and Sell / wallet values.

No backend/database/trading-provider changes.
No server restart is performed.

Install:
  unzip -o Solana-Multi-Wallet-v6.9-Per-Wallet-Trade.zip
  bash install.sh
  bash push-v6.9.sh
