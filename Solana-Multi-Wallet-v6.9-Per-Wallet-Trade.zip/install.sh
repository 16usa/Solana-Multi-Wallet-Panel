#!/usr/bin/env bash
set -euo pipefail

TARGETS=(
  "artifacts/solana-multi-wallet/src/pages/home.tsx"
  "artifacts/solana-multi-wallet/src/index.css"
)

for file in "${TARGETS[@]}"; do
  if [ ! -f "$file" ]; then
    echo "ERROR: expected file not found: $file"
    exit 1
  fi
  cp "$file" "$file.bak-v6.9"
done

python3 patch/apply-v6-9.py

echo
echo "v6.9 per-wallet trade amounts installed."
echo "Each wallet now has its own BUY SOL amount and SELL %."
echo "Trade all keeps its separate global BUY / SELL values."
echo "No server restart was performed."
echo "No Console commands were run."
echo "Run: bash push-v6.9.sh"
