Solana Multi Wallet Compact v2

What this patch changes:
- Makes the initial mobile screen substantially more compact.
- Keeps Add wallet and Validate on the same row as their input.
- Reduces vertical section spacing and empty-state spacing.
- Keeps iPhone input font at 16px to avoid Safari focus zoom.
- Makes wallet rows compact when wallets are added.
- Keeps the page growing naturally as more wallets are added.
- Forces the wallet selector into the same monochrome black/white style.
- Does not change trading logic, API calls, wallet logic, or server startup.
- Does not restart the Replit app.

Install from the existing project root:
  unzip -o Solana-Multi-Wallet-Compact-v2.zip
  bash install.sh

Then refresh the page. Restart manually only if Replit does not hot-reload CSS.
