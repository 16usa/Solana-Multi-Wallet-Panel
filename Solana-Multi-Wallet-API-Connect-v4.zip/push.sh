#!/usr/bin/env bash
set -euo pipefail

git add \
  artifacts/solana-multi-wallet/src/pages/home.tsx \
  artifacts/solana-multi-wallet/src/index.css \
  artifacts/solana-multi-wallet/vite.config.ts \
  artifacts/solana-multi-wallet/.replit-artifact/artifact.toml \
  scripts/run-wallet-web.sh

if git diff --cached --quiet; then
  echo "Nothing new to commit."
else
  git commit -m "Fix wallet API routing and row connections"
fi

git push
