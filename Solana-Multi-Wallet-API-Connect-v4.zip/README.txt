Solana Multi Wallet v4 — API routing + per-row connect

What changes:
- Fixes the Replit preview /api routing by running the API beside the web preview.
- Vite proxies /api/* to the local wallet API.
- Adds CONNECT / CONNECTED to every wallet row.
- Clicking CONNECT targets that exact public address.
- If another wallet is connected, it disconnects first, then opens wallet selection.
- A mismatched connected address is reported clearly.
- On iPhone Safari, the UI explains that Phantom/Solflare signing must be done from the wallet app's in-app browser.
- BUY/SELL logic from v3 is preserved.
- No private keys or seed phrases are stored.

Install:
  unzip -o Solana-Multi-Wallet-API-Connect-v4.zip
  bash install.sh
  bash push.sh

Important:
- install.sh does NOT restart the server.
- No Console commands are run.
- After push, restart manually from Replit Console when you choose.
- The new API routing takes effect after that manual restart.

First verification after manual restart:
1. Refresh the page.
2. Paste a mint and tap Validate.
3. The red HTML/404 response should be gone.
4. Open the same site inside Phantom or Solflare mobile browser on iPhone.
5. Tap CONNECT beside one row.
6. Confirm that row changes to CONNECTED only when the connected address matches it.
