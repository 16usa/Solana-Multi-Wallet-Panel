#!/usr/bin/env bash
set -euo pipefail

TARGETS=(
  "artifacts/solana-multi-wallet/src/pages/home.tsx"
  "artifacts/solana-multi-wallet/src/index.css"
  "artifacts/solana-multi-wallet/vite.config.ts"
  "artifacts/solana-multi-wallet/.replit-artifact/artifact.toml"
)

for file in "${TARGETS[@]}"; do
  if [ ! -f "$file" ]; then
    echo "ERROR: expected file not found: $file"
    echo "Run this patch from the existing project root."
    exit 1
  fi
done

for file in "${TARGETS[@]}"; do
  cp "$file" "$file.bak-v4"
done

cp patch/artifacts/solana-multi-wallet/src/pages/home.tsx \
   artifacts/solana-multi-wallet/src/pages/home.tsx

cp patch/artifacts/solana-multi-wallet/src/index.css \
   artifacts/solana-multi-wallet/src/index.css

cp patch/artifacts/solana-multi-wallet/vite.config.ts \
   artifacts/solana-multi-wallet/vite.config.ts

cp patch/artifacts/solana-multi-wallet/.replit-artifact/artifact.toml \
   artifacts/solana-multi-wallet/.replit-artifact/artifact.toml

cp patch/scripts/run-wallet-web.sh \
   scripts/run-wallet-web.sh

chmod +x scripts/run-wallet-web.sh

echo
echo "v4 installed."
echo "No server restart was performed."
echo "No Console commands were run."
echo "Next: bash push.sh"
