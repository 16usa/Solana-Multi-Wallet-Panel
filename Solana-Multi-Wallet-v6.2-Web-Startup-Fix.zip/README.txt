Solana Multi Wallet v6.2 — frontend workflow startup fix

Fixes:
- Restores the last known-good root .replit workflow format.
- Removes the reserved-vm value from development config because Replit Workflows
  was rejecting/parsing it incorrectly in this project.
- Starts the web artifact directly with its pnpm dev command.
- Makes Vite tolerant of missing generated env values:
    PORT defaults to 25364
    BASE_PATH defaults to /
    WALLET_API_PORT defaults to 8080
- Keeps /api proxied to the already-running API Server on port 8080.

This does NOT change:
- 24/7 execution logic
- encrypted wallet storage
- database schema
- TP/SL worker
- RPC configuration

Install:
  unzip -o Solana-Multi-Wallet-v6.2-Web-Startup-Fix.zip
  bash install.sh
  bash push-v6.2.sh

No restart is performed.
After push, restart manually and start the web workflow again.

Reserved VM:
For final 24/7 publishing, select Reserved VM in Replit's deployment UI after
development is stable. Do not force it through the root .replit workflow config.
