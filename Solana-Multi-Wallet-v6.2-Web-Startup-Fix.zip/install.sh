#!/usr/bin/env bash
set -euo pipefail

TARGETS=(
  ".replit"
  "artifacts/solana-multi-wallet/vite.config.ts"
  "artifacts/solana-multi-wallet/.replit-artifact/artifact.toml"
)

for file in "${TARGETS[@]}"; do
  if [ ! -f "$file" ]; then
    echo "ERROR: expected file not found: $file"
    exit 1
  fi
  cp "$file" "$file.bak-v6.2"
done

cp patch/.replit .replit
cp patch/artifacts/solana-multi-wallet/vite.config.ts    artifacts/solana-multi-wallet/vite.config.ts
cp patch/artifacts/solana-multi-wallet/.replit-artifact/artifact.toml    artifacts/solana-multi-wallet/.replit-artifact/artifact.toml

echo
echo "v6.2 web startup fix installed."
echo "No server restart was performed."
echo "No Console commands were run."
echo "Run: bash push-v6.2.sh"
