#!/usr/bin/env bash
set -euo pipefail

TARGETS=(
  "artifacts/api-server/src/lib/execution-engine.ts"
  "artifacts/solana-multi-wallet/src/pages/home.tsx"
)

for file in "${TARGETS[@]}"; do
  if [ ! -f "$file" ]; then
    echo "ERROR: expected file not found: $file"
    exit 1
  fi
  cp "$file" "$file.bak-v7.2.1"
done

python3 patch/apply-v7-2-1.py

echo
echo "v7.2.1 SOL/USD toggle fix installed."
echo "JUPITER_API_KEY is no longer required just to display/convert SOL and USD."
echo "Price sources: Jupiter when configured, then CoinGecko, then Coinbase."
echo "No server restart was performed."
echo "No Console commands were run."
echo "Run: bash push-v7.2.1.sh"
