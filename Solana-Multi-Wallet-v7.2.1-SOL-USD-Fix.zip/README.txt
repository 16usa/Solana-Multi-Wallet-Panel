Solana Multi Wallet v7.2.1 — SOL/USD Toggle Fix

Problem:
The first v7.2 switch refused to change from SOL to USD when the backend
could not load a SOL/USD rate. The primary source required JUPITER_API_KEY.

Fix:
- Jupiter is used when JUPITER_API_KEY is configured.
- If Jupiter is unavailable, the backend falls back to CoinGecko.
- If CoinGecko is unavailable, it falls back to Coinbase spot price.
- Pressing the SOL/USD switch now retries the rate immediately instead of
  depending only on the background refresh.

No UI redesign.
No database changes.
No server restart is performed.

Install:
  unzip -o Solana-Multi-Wallet-v7.2.1-SOL-USD-Fix.zip
  bash install.sh
  bash push-v7.2.1.sh

After push:
Restart API Server manually from Replit Console.
