#!/usr/bin/env bash
set -euo pipefail

TARGETS=(
  ".replit"
  "scripts/run-wallet-web.sh"
  "artifacts/solana-multi-wallet/.replit-artifact/artifact.toml"
  "artifacts/api-server/src/routes/solana.ts"
  "artifacts/api-server/src/lib/execution-engine.ts"
)

for file in "${TARGETS[@]}"; do
  if [ ! -f "$file" ]; then
    echo "ERROR: expected file not found: $file"
    exit 1
  fi
  cp "$file" "$file.bak-v6.1"
done

cp patch/.replit .replit
cp patch/scripts/run-wallet-web.sh scripts/run-wallet-web.sh
cp patch/artifacts/solana-multi-wallet/.replit-artifact/artifact.toml    artifacts/solana-multi-wallet/.replit-artifact/artifact.toml

chmod +x scripts/run-wallet-web.sh

python3 patch/fix-rpc.py

echo
echo "v6.1 startup fix installed."
echo "No server restart was performed."
echo "No Console commands were run."
echo "Run: bash push-v6.1.sh"
