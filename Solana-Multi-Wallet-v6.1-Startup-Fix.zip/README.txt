Solana Multi Wallet v6.1 startup fix

Fixes:
1. Restores a Replit-compatible .replit workflow/deployment structure.
2. Keeps Reserved VM as the deployment target.
3. Stops the web workflow from launching a second API server.
4. Web preview now proxies /api to the generated API Server on port 8080.
5. Normalizes SOLANA_RPC_URL in both API RPC clients:
   - trims whitespace
   - accepts an accidentally pasted SOLANA_RPC_URL= prefix
   - strips wrapping quotes
   - falls back to the public Solana mainnet RPC if the value is malformed

Install:
  unzip -o Solana-Multi-Wallet-v6.1-Startup-Fix.zip
  bash install.sh
  bash check-rpc.sh
  bash push-v6.1.sh

No script restarts the server.
Restart manually from Console only after the patch is installed/pushed.
