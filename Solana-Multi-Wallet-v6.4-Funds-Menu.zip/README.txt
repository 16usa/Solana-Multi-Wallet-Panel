Solana Multi Wallet v6.4 — compact funds menu

UI
- Adds ••• beside each execution wallet.
- Opens a mobile bottom sheet instead of adding withdrawal controls to the main page.
- Withdrawal destination can be saved locally on the current device.
- Per-wallet SOL withdrawal supports exact amount or MAX.
- Includes View Transactions inside the secondary menu.
- Adds a top ••• Funds menu with Withdraw All Wallets.

Backend
- Adds authenticated POST /api/execution/withdraw.
- Adds authenticated POST /api/execution/withdraw-all.
- Server signs SOL transfers with the encrypted execution-wallet key.
- MAX keeps a small SOL reserve for the network fee.
- MAX is blocked while AUTO is enabled on that wallet.
- Withdraw All skips wallets that currently have AUTO enabled.

Install:
  unzip -o Solana-Multi-Wallet-v6.4-Funds-Menu.zip
  bash install.sh
  bash push-v6.4.sh

No restart is performed by the patch.
Restart manually from Replit Console after installation/push.
