#!/usr/bin/env bash
set -euo pipefail

TARGETS=(
  "artifacts/api-server/src/lib/execution-engine.ts"
  "artifacts/api-server/src/routes/execution.ts"
  "artifacts/solana-multi-wallet/src/pages/home.tsx"
  "artifacts/solana-multi-wallet/src/index.css"
)

for file in "${TARGETS[@]}"; do
  if [ ! -f "$file" ]; then
    echo "ERROR: expected file not found: $file"
    exit 1
  fi
  cp "$file" "$file.bak-v7.2"
done

python3 patch/apply-v7-2.py

echo
echo "v7.2 SOL/USD currency toggle installed."
echo "No database migration is required."
echo "No server restart was performed."
echo "No Console commands were run."
echo "Run: bash push-v7.2.sh"
