Solana Multi Wallet v7.2 — SOL / USD Toggle

Adds one global currency switch beside the existing theme switch.

SOL mode:
- wallet balances display in SOL
- BUY amounts are entered in SOL
- Trade all BUY is entered in SOL
- withdrawal amount is entered in SOL
- token/entry prices display in SOL
- TOTAL / REALIZED / UNREALIZED P&L display in SOL

USD mode:
- wallet balances display in dollars
- BUY amounts are entered in USD
- Trade all BUY is entered in USD
- withdrawal amount is entered in USD
- token/entry prices display in dollars
- TOTAL / REALIZED / UNREALIZED P&L display in dollars

Percentage fields do not change:
- SELL %
- TP / TP SELL %
- SL / SL SELL %
- P&L %

Execution still happens natively in SOL. When USD mode is selected,
the frontend converts the requested USD amount to SOL using the latest
SOL/USD price immediately before sending the trade/withdraw request.

The SOL/USD rate is fetched from Jupiter Price API V3 through the backend,
using the project's existing JUPITER_API_KEY.

The selected currency and BUY amounts are saved locally on the device.
Switching SOL <-> USD converts the visible BUY/withdraw amounts so the
same approximate monetary amount is preserved.

Install:
  unzip -o Solana-Multi-Wallet-v7.2-SOL-USD-Toggle.zip
  bash install.sh
  bash push-v7.2.sh

No database migration.
No server restart is performed by the patch.
After push, restart API Server manually from Replit Console.
The web frontend may hot-reload automatically; restart it only if needed.
