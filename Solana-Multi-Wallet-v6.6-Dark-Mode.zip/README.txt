Solana Multi Wallet v6.6 — dark mode

Adds:
- Small theme switch immediately beside the 24/7 EXECUTION title.
- Pure black dark background with white text and monochrome controls.
- Dark styling for wallet rows, inputs, BUY/SELL controls, menus and bottom sheets.
- Theme preference is saved locally on the device/browser.
- No trading/backend/database logic is changed.

Install:
  unzip -o Solana-Multi-Wallet-v6.6-Dark-Mode.zip
  bash install.sh
  bash push-v6.6.sh

No restart is performed by the patch.
