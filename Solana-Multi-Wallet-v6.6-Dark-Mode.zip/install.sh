#!/usr/bin/env bash
set -euo pipefail

TARGETS=(
  "artifacts/solana-multi-wallet/src/pages/home.tsx"
  "artifacts/solana-multi-wallet/src/index.css"
)

for file in "${TARGETS[@]}"; do
  if [ ! -f "$file" ]; then
    echo "ERROR: expected file not found: $file"
    exit 1
  fi
  cp "$file" "$file.bak-v6.6"
done

python3 patch/apply-v6-6.py

echo
echo "v6.6 dark mode installed."
echo "Added compact theme switch beside 24/7 EXECUTION."
echo "No server restart was performed."
echo "No Console commands were run."
echo "Run: bash push-v6.6.sh"
