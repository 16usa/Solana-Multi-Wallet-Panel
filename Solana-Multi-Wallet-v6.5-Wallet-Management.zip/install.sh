#!/usr/bin/env bash
set -euo pipefail

TARGETS=(
  "artifacts/solana-multi-wallet/src/pages/home.tsx"
  "artifacts/solana-multi-wallet/src/index.css"
  "artifacts/api-server/src/lib/execution-engine.ts"
  "artifacts/api-server/src/routes/execution.ts"
)

for file in "${TARGETS[@]}"; do
  if [ ! -f "$file" ]; then
    echo "ERROR: expected file not found: $file"
    exit 1
  fi
  cp "$file" "$file.bak-v6.5"
done

python3 patch/apply-v6-5.py

echo
echo "v6.5 wallet management installed."
echo "Added DISABLE / ENABLE + protected DELETE WALLET."
echo "No server restart was performed."
echo "No Console commands were run."
echo "Run: bash push-v6.5.sh"
