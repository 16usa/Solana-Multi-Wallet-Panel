Solana Multi Wallet v6.5 — wallet management

Adds inside each wallet's existing ••• bottom sheet:
- DISABLE WALLET
- ENABLE WALLET
- DELETE WALLET

Safety:
- Disabling a wallet also switches all of its AUTO strategies off.
- BUY / SELL / AUTO controls are disabled while that wallet is OFF.
- A disabled wallet can still withdraw SOL so it can be emptied safely.
- Permanent deletion requires:
  1. wallet is disabled
  2. AUTO is off
  3. no positive SPL / Token-2022 balances
  4. SOL balance is only fee dust (<= 10,000 lamports)
  5. user types DELETE in the confirmation prompt
- Deleting removes the encrypted execution key from the database and cannot be undone.

Install:
  unzip -o Solana-Multi-Wallet-v6.5-Wallet-Management.zip
  bash install.sh
  bash push-v6.5.sh

No restart is performed by the patch.
Restart manually from Replit Console after install/push.
