#!/usr/bin/env bash
set -euo pipefail

TARGETS=(
  "artifacts/solana-multi-wallet/src/pages/home.tsx"
  "artifacts/solana-multi-wallet/src/index.css"
)

for file in "${TARGETS[@]}"; do
  if [ ! -f "$file" ]; then
    echo "ERROR: expected file not found: $file"
    exit 1
  fi
  cp "$file" "$file.bak-v6.3"
done

cp patch/artifacts/solana-multi-wallet/src/pages/home.tsx \
   artifacts/solana-multi-wallet/src/pages/home.tsx
cp patch/artifacts/solana-multi-wallet/src/index.css \
   artifacts/solana-multi-wallet/src/index.css

echo
echo "v6.3 wallet tools installed."
echo "Added COPY ADDRESS + REFRESH BALANCE."
echo "No server restart was performed."
echo "No Console commands were run."
echo "Run: bash push-v6.3.sh"
