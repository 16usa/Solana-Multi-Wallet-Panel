Solana Multi Wallet v6.3 — Copy Address + Refresh Balance

Adds two compact controls to every execution wallet:
- COPY — copies the full Solana public address to the clipboard.
- ↻ — refreshes that wallet's SOL balance immediately.

Notes:
- No backend/database changes.
- No change to BUY/SELL/TP/SL logic.
- No private keys are exposed.
- The existing 5-second automatic refresh remains in place.
- The manual ↻ button is useful immediately after funding a wallet.

Install:
  unzip -o Solana-Multi-Wallet-v6.3-Copy-Refresh.zip
  bash install.sh
  bash push-v6.3.sh

No server restart is performed by the patch.
