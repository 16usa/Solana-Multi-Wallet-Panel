Solana Multi Wallet v7.1 — P&L Accounting

UI:
- Adds a compact summary inside Trade all:
    TOTAL P&L       +0.0500 SOL   +8.33%
    REALIZED        +0.0200 SOL
    UNREALIZED      +0.0300 SOL
- No duplicate token-quantity field is added.
- Individual wallet P&L remains visible in every wallet row.

Meaning:
- REALIZED = profit/loss already locked in by manual SELL, SELL ALL, TP or SL.
- UNREALIZED = current value of tokens still held minus their remaining cost basis.
- TOTAL P&L = REALIZED + UNREALIZED.
- TOTAL % = TOTAL P&L divided by total SOL invested in the current position cycle.

Accounting:
- BUY adds SOL to remaining position cost and total invested.
- Additional BUY keeps weighted cost basis.
- Partial SELL removes the matching fraction of cost basis and records realized P&L.
- Full SELL closes the position while keeping realized P&L visible.
- The next BUY after a fully closed position begins a fresh P&L cycle.
- AUTO TP/SL sales use the same accounting as manual sales.
- Confirmed transaction wallet SOL delta is used for realized sale proceeds.
- Existing pre-v7.1 open positions are supported by falling back to their saved entry price.
- Realized profits/losses from sales made BEFORE v7.1 cannot be reconstructed and start at 0.

Database:
- Adds position_cost_sol
- Adds total_invested_sol
- Adds realized_pnl_sol
- install.sh runs the existing Drizzle database push.
- No server restart is performed.

Install:
  unzip -o Solana-Multi-Wallet-v7.1-PnL-Accounting.zip
  bash install.sh
  bash push-v7.1.sh

After push:
- Restart API Server manually from Replit Console.
- Web may hot-reload automatically; restart it manually only if needed.
