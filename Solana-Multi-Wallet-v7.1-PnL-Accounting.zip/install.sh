#!/usr/bin/env bash
set -euo pipefail

TARGETS=(
  "lib/db/src/schema/execution.ts"
  "artifacts/api-server/src/lib/execution-engine.ts"
  "artifacts/api-server/src/routes/execution.ts"
  "artifacts/api-server/src/lib/strategy-worker.ts"
  "artifacts/solana-multi-wallet/src/pages/home.tsx"
  "artifacts/solana-multi-wallet/src/index.css"
)

for file in "${TARGETS[@]}"; do
  if [ ! -f "$file" ]; then
    echo "ERROR: expected file not found: $file"
    exit 1
  fi
  cp "$file" "$file.bak-v7.1"
done

if ! command -v pnpm >/dev/null 2>&1; then
  echo "ERROR: pnpm is not available in this Shell."
  exit 1
fi

python3 patch/apply-v7-1.py

echo
echo "Applying P&L database columns..."
pnpm --filter @workspace/db push

echo
echo "v7.1 P&L accounting installed."
echo "Added TOTAL / REALIZED / UNREALIZED P&L for the selected mint."
echo "No server restart was performed."
echo "No Console restart commands were run."
echo "Run: bash push-v7.1.sh"
