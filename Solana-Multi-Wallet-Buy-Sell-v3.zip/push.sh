#!/usr/bin/env bash
set -euo pipefail

git add \
  artifacts/solana-multi-wallet/src/pages/home.tsx \
  artifacts/solana-multi-wallet/src/index.css \
  artifacts/api-server/src/routes/solana.ts

if git diff --cached --quiet; then
  echo "Nothing new to commit."
else
  git commit -m "Add multi-wallet buy and sell controls"
fi

git push
