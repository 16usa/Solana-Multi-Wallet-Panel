#!/usr/bin/env bash
set -euo pipefail

FILES=(
  "artifacts/solana-multi-wallet/src/pages/home.tsx"
  "artifacts/solana-multi-wallet/src/index.css"
  "artifacts/api-server/src/routes/solana.ts"
)

for file in "${FILES[@]}"; do
  if [ ! -f "$file" ]; then
    echo "ERROR: expected project file not found: $file"
    echo "Run this patch from the existing project root."
    exit 1
  fi
done

for file in "${FILES[@]}"; do
  cp "$file" "$file.bak-trade-v3"
done

cp "patch/artifacts/solana-multi-wallet/src/pages/home.tsx" \
   "artifacts/solana-multi-wallet/src/pages/home.tsx"

cp "patch/artifacts/solana-multi-wallet/src/index.css" \
   "artifacts/solana-multi-wallet/src/index.css"

cp "patch/artifacts/api-server/src/routes/solana.ts" \
   "artifacts/api-server/src/routes/solana.ts"

echo
echo "Multi-wallet BUY/SELL v3 patch installed."
echo "No server restart was performed."
echo "No Console commands were run."
echo "Run: bash push.sh"
