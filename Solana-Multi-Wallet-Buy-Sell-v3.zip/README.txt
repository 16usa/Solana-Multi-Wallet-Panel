Solana Multi Wallet BUY/SELL v3

Adds:
- BUY ALL for all active wallets.
- SELL ALL for all active wallets.
- Per-wallet BUY and SELL controls.
- Per-wallet BUY amount in SOL.
- Per-wallet SELL percentage.
- Global BUY amount per wallet.
- Global SELL percentage per wallet.
- SELL amount is calculated from that wallet's live SPL-token balance.
- 100% means the full detected token balance.
- Pump.fun sell routing first; Jupiter fallback for other tokens.
- Matching wallet must still sign its prepared transaction.

Important:
- This patch does NOT restart the server.
- This patch does NOT run Console commands.
- This patch does NOT store private keys or seed phrases.
- install.sh only patches files.
- push.sh commits and pushes the exact changed files.

Install:
  unzip -o Solana-Multi-Wallet-Buy-Sell-v3.zip
  bash install.sh
  bash push.sh

Restart manually in Replit Console only when you decide to.
